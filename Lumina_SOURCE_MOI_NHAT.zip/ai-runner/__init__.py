"""Image-processing package."""
